#!/bin/bash

if [ "$1" == "-h" ] || [ $# -ne 1 ]; then
	echo "Uso: $0 <destino>"
	echo "Ejemplo: $0 /backup_dir"
	exit 1
fi

DESTINO=$1

if [ ! -d "$DESTINO" ]; then
	echo "Error: El directorio destino $DESTINO no existe"
	exit 1
fi

FECHA=$(date +%Y%m%d)
DB_BACKUP="mariadb_bkp_$FECHA.sql.gz"

echo "Creando backup de la base de datos en $DESTINO/DB_BACKUP..."

mysqldump -u root -p --all-databases | gzip > "$DESTINO/$DB_BACKUP"

if [ $? -eq 0 ]; then
	echo "Backup de la base de datos completado: $DESTINO/$DB_BACKUP"
else
	echo "Error durante la creacion del backup"
	exit 1
fi


